﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Daycareworld
{
    public partial class createaccount : Form
    {
        public createaccount()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

         

            {
                if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "")
                {
                    MessageBox.Show("Please enter a username and password.");
                    return;
                }
                else if (textBox2.Text == textBox3.Text)
                {

                    try
                    {
                    
                        Connection.Connection.DB();
                        DBHelper.DBHelper.gen = "Select count(*) from login where [username] = '" + username + "'";
                        DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                        int count = (int)DBHelper.DBHelper.command.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("Username already exists. Please choose a different username.");
                            return;
                        }

                       
                        DBHelper.DBHelper.gen = "Insert into login ([username], [password]) values (@username, @password)";
                        DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                        DBHelper.DBHelper.command.Parameters.AddWithValue("@username", username);

                        DBHelper.DBHelper.command.Parameters.AddWithValue("@password", password);

                        DBHelper.DBHelper.command.ExecuteNonQuery();




                       
                        MessageBox.Show("Account created successfully.");
                        this.Hide(); 
                        login loginForm = new login();
                        loginForm.Show(); 



                    }
                    catch
                    {
                        MessageBox.Show("Error creating account: ");
                    }
                    finally
                    {
                        Connection.Connection.conn.Close();

                    }
                }
                else
                {

                    MessageBox.Show("Password did not match");
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox2.Focus();
                }
            }
                    
            
            
    }
    
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
            {
                login login = new login();
                login.Show();
            this.Hide();
            }
        void showpass()
        {
            if (checkBox1.Checked)
            {

                textBox2.PasswordChar = '\0';
                textBox3.PasswordChar = '\0';
            }
            else
            {
                textBox2.PasswordChar = '*';
                textBox3.PasswordChar = '*';
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            showpass();
        }
    }
    }

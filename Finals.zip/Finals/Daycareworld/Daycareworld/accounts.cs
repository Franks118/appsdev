﻿using Daycareworld.Connection;
using Daycareworld.DBHelper;
using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;

using System.Xml.Linq;
using System.Data.Common;

namespace Daycareworld
{
    public partial class accounts : Form
    {
        public accounts()
        {
            InitializeComponent();
            viewer();
        }
        //from connectio and dbhelper
        public OleDbConnection connection;
        public OleDbDataAdapter dataAdapter;
        public DataSet dataSet;
        public int selectedRowIndex;




        private void accounts_Load(object sender, EventArgs e)
        {
            
            this.loginTableAdapter.Fill(this.dCWDataSet.login);

        }

        private void label1_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(textBox1.Text))
                {
                    string search = "select * from [login] where [username] like'" + textBox1.Text + "'";
                    DBHelper.DBHelper.fill(search, dataGridView1);



                }
                else
                {

                    MessageBox.Show("no idea");
                }




            }
            catch
            {
                MessageBox.Show("YOU'VE DONE SOMETHING WRONG!!!!!");



            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = dataSet.Tables["DCW"].Rows[selectedRowIndex];

                if (selectedRow["username"] != DBNull.Value)
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand("DELETE FROM login WHERE username = @id", connection);
                    command.Parameters.AddWithValue("@id", selectedRow["username"]);


                    command.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfully.");
                    viewer();

                }
                else
                {
                    MessageBox.Show(" cannot be Empty!!?!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }
        void viewer()
        {
            try
            {
                //new connection for easier integration
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DCW.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM login", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "DCW");
                dataGridView1.DataSource = dataSet.Tables["DCW"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            viewer();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Menus menu = new Menus();
            this.Hide();
            menu.Show();
        }
    }
}

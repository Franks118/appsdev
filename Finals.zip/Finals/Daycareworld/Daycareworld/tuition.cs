﻿using Daycareworld.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Daycareworld
{
    public partial class tuition : Form
    {
        public OleDbConnection connection;
        public OleDbDataAdapter dataAdapter;
        public DataSet dataSet;
        public int selectedRowIndex;
        public tuition()
        {
            InitializeComponent();
            viewer();
        }

        void viewer()
        {
            try
            {
                //new connection for easier integration
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DCW.accdb;";
                connection = new OleDbConnection(connectionString);
                //only chanmge "FROM THEN NAME OF THE TABLE"
                dataAdapter = new OleDbDataAdapter("SELECT * FROM tuition", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "DCW");
                dataGridView1.DataSource = dataSet.Tables["DCW"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void tuition_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
           Menus menus = new Menus();
            this.Hide();
            menus.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                Connection.Connection.DB();
                OleDbCommand command = new OleDbCommand("INSERT INTO tuition (tuition, miscellaneos, equipment, others, discount) VALUES (@ttuition, @miscellaneos, @equipment, @others, @discount)", connection);
                command.Parameters.AddWithValue("@tuition", float.Parse(textBox1.Text));
                command.Parameters.AddWithValue("@miscellaneos", float.Parse(textBox2.Text));
                command.Parameters.AddWithValue("@equipment", float.Parse(textBox3.Text));
                command.Parameters.AddWithValue("@others", float.Parse(textBox4.Text));
                command.Parameters.AddWithValue("@discount", float.Parse(textBox5.Text));

                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                viewer();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        //update same code used for admin dashboard just change the values
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                try
                {
                    int INDEXOFROW = dataGridView1.SelectedCells[0].RowIndex;
                    int selectindexrows = dataGridView1.SelectedCells[0].ColumnIndex;
                    string column = dataGridView1.Columns[selectindexrows].Name;
                    DataRow Row = dataSet.Tables["DCW"].Rows[INDEXOFROW];

                    switch (column)
                    {
                        case "ttuition":
                            Row["tuition"] = float.Parse(textBox1.Text);
                            break;
                        case "miscellaneos":
                            Row["miscellaneos"] = float.Parse(textBox2.Text);
                            break;
                        case "equipment":
                            Row["equipment"] = float.Parse(textBox3.Text);
                            break;
                        case "others":
                            Row["others"] = float.Parse(textBox4.Text);
                            break;
                        case "discount":
                            Row["discount"] = float.Parse(textBox5.Text);
                            break;
                        default:
                            MessageBox.Show("Cannot Update");
                            return;
                    }

                    connection.Open();
                    OleDbCommand command = new OleDbCommand("UPDATE tuition SET [" + column + "] = @Value WHERE tuition = @ID", connection);
                    command.Parameters.AddWithValue("@Value", Row[column]);
                    command.Parameters.AddWithValue("@ID", Row["tuition"]);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Data updated successfully.");
                    viewer();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("select a cell to update.");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                textBox1.Text = dataGridView1[0, e.RowIndex].Value.ToString();
                textBox2.Text = dataGridView1[1, e.RowIndex].Value.ToString();
                textBox3.Text = dataGridView1[2, e.RowIndex].Value.ToString();
                textBox4.Text = dataGridView1[3, e.RowIndex].Value.ToString();
                textBox5.Text = dataGridView1[4, e.RowIndex].Value.ToString();

            }
            catch (Exception)
            {
                MessageBox.Show("ERROR!!!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                DataRow selectedRow = dataSet.Tables["DCW"].Rows[selectedRowIndex];

                if (selectedRow["tuition"] != DBNull.Value)
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand("DELETE FROM tuition WHERE [tuition] = @ttuition", connection);
                    command.Parameters.AddWithValue("@ttuition", selectedRow["tuition"]);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfully.");
                    viewer();
                }
                else
                {
                    MessageBox.Show(" cannot be Empty!!?!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }
    }
}

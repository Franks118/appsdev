﻿using Daycareworld.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Daycareworld
{
    public partial class activities : Form
    {
        public activities()
        {
            InitializeComponent();
            viewer();
        }
        public OleDbConnection connection;
        public OleDbDataAdapter dataAdapter;
        public DataSet dataSet;
        public int selectedRowIndex;
        private void label1_Click(object sender, EventArgs e)
        {
            user user = new user();
            this.Hide();
            user.Show();
        }
        void viewer()
        {
            try
            {
                //new connection for easier integration
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DCW.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM act", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "DCW");
                dataGridView1.DataSource = dataSet.Tables["DCW"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }


        }
    }
}

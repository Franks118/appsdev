﻿using Daycareworld.Connection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
namespace Daycareworld
{
    public partial class tuitioncompute : Form
    {
        public OleDbConnection connection;
        public OleDbDataAdapter dataAdapter;
        public DataSet dataSet;
        public int selectedRowIndex;
        public tuitioncompute()
        {
            InitializeComponent();
            viewer();
        }
        void viewer()
        {
            try
            {
                //new connection for easier integration
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DCW.accdb;";
                connection = new OleDbConnection(connectionString);
                //only chanmge "FROM THEN NAME OF THE TABLE"
                dataAdapter = new OleDbDataAdapter("SELECT * FROM tuition", connection);
                dataSet = new DataSet();

                connection.Open();
                dataAdapter.Fill(dataSet, "DCW");
                dataGridView1.DataSource = dataSet.Tables["DCW"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                textBox1.Text = dataGridView1[0, e.RowIndex].Value.ToString();
                textBox2.Text = dataGridView1[1, e.RowIndex].Value.ToString();
                textBox3.Text = dataGridView1[2, e.RowIndex].Value.ToString();
                textBox4.Text = dataGridView1[3, e.RowIndex].Value.ToString();
                textBox5.Text = dataGridView1[4, e.RowIndex].Value.ToString();

            }
            catch (Exception)
            {
                MessageBox.Show("ERROR!!!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
         
            int tx1 = Convert.ToInt32(textBox1.Text);
            int tx2 = Convert.ToInt32(textBox2.Text);
            int tx3 = Convert.ToInt32(textBox3.Text);
            int tx4 = Convert.ToInt32(textBox4.Text);
            int tx5 = Convert.ToInt32(textBox5.Text);
            int total = tx1 + tx2 + tx3 + tx4 +tx5;  
            textBox6.Text ="$"+ total.ToString()+"";
            MessageBox.Show($"YOUR TOTAL IS ${total}  ");


        }

        private void label7_Click(object sender, EventArgs e)
        {
            user user = new user();
            user.Show();
            this.Hide();
        }
    }
}

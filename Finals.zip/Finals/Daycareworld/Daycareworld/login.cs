﻿using Daycareworld.Connection;
using Daycareworld.DBHelper;
using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;



namespace Daycareworld
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        public static string sent = "";

        private void label2_Click(object sender, EventArgs e)
        {

        }
     
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Connection.Connection.DB();
                DBHelper.DBHelper.gen = "Select * from login where [username] = '" + textBox1.Text + "' and [password] = '" + textBox2.Text+ "'";
                DBHelper.DBHelper.command = new OleDbCommand(DBHelper.DBHelper.gen, Connection.Connection.conn);
                DBHelper.DBHelper.reader = DBHelper.DBHelper.command.ExecuteReader();

                if (DBHelper.DBHelper.reader.HasRows)
                {
                    DBHelper.DBHelper.reader.Read();
                   
                    string username = DBHelper.DBHelper.reader["username"].ToString();
                    sent = username;
                    string password = DBHelper.DBHelper.reader["password"].ToString();

                 

                    if (username == "admin" && password == "admin"||username =="ADMIN"&& password== "ADMIN")
                    {
                       
                        this.Hide();
                     admindashboard ad = new admindashboard();
                        ad.Show();
                       
                    }
                    else
                    {
                       
                        user use = new user();
                        use.Show();
                        this.Hide();
                       
                       
                    }

                }
                else
                {
                    MessageBox.Show("Invalid Username and Password");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                Connection.Connection.conn.Close();
            }
            catch (Exception ex)
            {
                Connection.Connection.conn.Close();
                MessageBox.Show(ex.Message);

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            createaccount crtacc = new createaccount();
            crtacc.Show();
            this.Hide();
        }
        void showpass()
        {
            if (checkBox1.Checked)
            {

                textBox2.PasswordChar = '\0';
               
            }
            else
            {
                textBox2.PasswordChar = '*';
               
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            showpass();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            termsagreement tmr = new termsagreement();
            this.Hide();
            tmr.Show();
        }
    }
}

﻿using Daycareworld.Connection;
using Daycareworld.DBHelper;
using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Xml.Linq;
using System.Data.Common;

namespace Daycareworld
{
    public partial class updateaccountuser : Form
    {
        //brute force method
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\DCW.accdb");
        public updateaccountuser()
        {
            InitializeComponent();
        }
       

        private void updateaccountuser_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            user use = new user();
           use.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into admindashboard(id,firstname,lastname,Gmail,cpnumber)values('" + float.Parse(textBox1.Text) + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + float.Parse(textBox6.Text) + "')";
                cmd.ExecuteNonQuery();


                conn.Close();
                
                MessageBox.Show("saved");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                conn.Close();

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

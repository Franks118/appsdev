﻿using Daycareworld.Connection;
using Daycareworld.DBHelper;
using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Xml.Linq;
using System.Data.Common;
namespace Daycareworld
{
    public partial class user : Form
    {
        public user()
        {
            InitializeComponent();
            label2.Text = login.sent;
        }
        public OleDbConnection connection;
        public OleDbDataAdapter dataAdapter;
        public DataSet dataSet;
        public int selectedRowIndex;

        private void label2_Click(object sender, EventArgs e)
        {
            updateaccountuser update = new updateaccountuser();
            this.Hide();
            update.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            tuitioncompute tuitioncompute = new tuitioncompute();
            tuitioncompute.Show();
            this.Hide();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            activities act = new activities();
            act.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            login llogin = new login(); 
            llogin.Show();
            this.Hide();
        }
    }
}

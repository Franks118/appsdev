﻿using Daycareworld.Connection;
using Daycareworld.DBHelper;
using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.OleDb;
using System.Xml.Linq;
using System.Data.Common;

namespace Daycareworld
{
    public partial class admindashboard : Form
    {
        public admindashboard()
        {
            InitializeComponent();
            viewer();
        }
        public OleDbConnection connection;
        public OleDbDataAdapter dataAdapter;
        public DataSet dataSet;
        public int selectedRowIndex;

        void viewer()
        {
            try
            {
                //new connection for easier integration
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DCW.accdb;";
                connection = new OleDbConnection(connectionString);
                dataAdapter = new OleDbDataAdapter("SELECT * FROM admindashboard", connection);
                dataSet = new DataSet(); 

                connection.Open();
                dataAdapter.Fill(dataSet, "DCW");
                dataGridView1.DataSource = dataSet.Tables["DCW"];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }


        }


    
        void refresh()
        {


            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox6.Text = "";
            viewer();
        }

            private void button7_Click(object sender, EventArgs e)
        {
                refresh();
        }
        //save
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                Connection.Connection.DB();
                OleDbCommand command = new OleDbCommand("INSERT INTO admindashboard (id, firstname, lastname, Gmail, cpnumber) VALUES (@id, @firstname, @lastname, @Gmail, @cpnumber)", connection);
                command.Parameters.AddWithValue("@id", float.Parse(textBox1.Text));
                command.Parameters.AddWithValue("@firstname", textBox2.Text);
                command.Parameters.AddWithValue("@lastname", textBox3.Text);
                command.Parameters.AddWithValue("@Gmail", textBox4.Text);
                command.Parameters.AddWithValue("@cpnumber", float.Parse(textBox6.Text));
               
                command.ExecuteNonQuery();
                MessageBox.Show("Data saved successfully.");
                viewer();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
        //scan/view optional to be remove
        private void button5_Click(object sender, EventArgs e)
        {
            viewer();
        }
        /*
         //suggested code for referrence
                         private void btnUpdate_Click(object sender, EventArgs e)
                    {
                        sql = "Update stock SET Description ='" + txtdescription.Text +
                       "',Sprice = '" + txtsprice.Text +
                       "',Reorderpt = " + txtreorderpoint.Text +
                      8
                 ",Unit ='" + txtunit.Text +
                 "',Expirydate ='" + dpexpirydate.Value.Date +
                 "',Datemodified = '" + DateTime.Now.ToShortDateString() +
                 "',Stockonhand = " + txtstockonhand.Text +
                 ",Category = '" + cbocategory.Text +
                 "' where Itemcode = " + txtItemNo.Text + "";
                 DBHelper.DBHelper.ModifyRecord(sql);
                 MessageBox.Show("Data has been updated...", "Update stock", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
                 Form1_Load(sender, e);
                 }
         
         */
        //with switch case version but same logic
        //update
        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                try
                {
                    int INDEXOFROW = dataGridView1.SelectedCells[0].RowIndex;
                    int selectindexrows = dataGridView1.SelectedCells[0].ColumnIndex;
                    string column = dataGridView1.Columns[selectindexrows].Name;
                    DataRow Row = dataSet.Tables["DCW"].Rows[INDEXOFROW];

                    switch (column)
                    {
                        case "id":
                            Row["id"] = int.Parse(textBox1.Text);
                            break;
                        case "firstname":
                            Row["firstname"] = textBox2.Text;
                            break;
                        case "lastname":
                            Row["lastname"] = textBox3.Text;                          
                             break;
                        case "Gmail":
                            Row["Gmail"] =textBox4.Text;
                            break;
                        case "cpnumber":
                            Row["cpnumber"] = int.Parse(textBox6.Text);
                            break;                  
                        default:
                            MessageBox.Show("Cannot Update");
                            return;
                    }

                    connection.Open();
                    OleDbCommand command = new OleDbCommand("UPDATE admindashboard SET [" + column + "] = @Value WHERE id = @ID", connection);
                    command.Parameters.AddWithValue("@Value", Row[column]);
                    command.Parameters.AddWithValue("@ID", Row["id"]);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Data updated successfully.");
                    viewer(); 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (connection != null && connection.State == ConnectionState.Open)
                    {
                        connection.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a cell to update.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                textBox1.Text = dataGridView1[0, e.RowIndex].Value.ToString();
                textBox2.Text = dataGridView1[1, e.RowIndex].Value.ToString();
                textBox3.Text = dataGridView1[2, e.RowIndex].Value.ToString();
                textBox4.Text = dataGridView1[3, e.RowIndex].Value.ToString();
                textBox6.Text = dataGridView1[4, e.RowIndex].Value.ToString();
               
            }
            catch (Exception) {
                MessageBox.Show("ERROR!!!");
            }
        }
                //suggested code for referrence
                                /*private void btnDelete_Click(object sender, EventArgs e)
                         {
                         var res = MessageBox.Show("Are you sure you want to delet this record?"
                         , "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                         if(res ==DialogResult.Yes)
                         {
                         sql = "Delete * from stock where Itemcode =" + txtItemNo.Text + "";
                         DBHelper.DBHelper.ModifyRecord(sql);
                         Form1_Load(sender, e);
                         }
                         }*/
                               
        private void button3_Click(object sender, EventArgs e) //delete with modified error catching
        {
            
              
                    try
                    {
                        int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                        DataRow selectedRow = dataSet.Tables["DCW"].Rows[selectedRowIndex];

                        if (selectedRow["id"] != DBNull.Value)
                        {
                            connection.Open();
                            OleDbCommand command = new OleDbCommand("DELETE FROM admindashboard WHERE id = @id", connection);
                            command.Parameters.AddWithValue("@id", selectedRow["id"]);
                            command.ExecuteNonQuery();
                            MessageBox.Show("Record deleted successfully.");
                        viewer();
                        }
                        else
                        {
                            MessageBox.Show(" cannot be Empty!!?!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                    finally
                    {
                        if (connection != null && connection.State == ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    
                }
           
        }

        private void button4_Click(object sender, EventArgs e)//search
        {
            try {
                if (!string.IsNullOrEmpty(textBox5.Text))
                {
                    string search = "select * from [admindashboard] where [firstname] like'" + textBox5.Text + "'";
                    DBHelper.DBHelper.fill(search, dataGridView1);



                }
                else { 
                
                viewer();
                }
            



            } catch {
                MessageBox.Show("YOU'VE DONE SOMETHING WRONG!!!!!");
            
            
            
            }
           

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Menus menu = new Menus();
            this.Hide();
            menu.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            login log = new login();
            log.Show();
            this.Hide();
        }
    }
    }



﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ddaycare
{
    public partial class Form2 : Form
    {
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\practice.accdb");
        public Form2()
        {
            InitializeComponent();
        }

        void viewer() {
            try
            {
                conn.Open();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from data";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter dp = new OleDbDataAdapter(cmd);
                dp.Fill(dt);
                dataGridView1.DataSource = dt;

                conn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }


        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into data(ID,firstname,lastname,address)values('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "')";
                cmd.ExecuteNonQuery();
               

                conn.Close();
                viewer();
                MessageBox.Show("saved");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                conn.Close();

            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            viewer();
        }

        private void button6_Click(object sender, EventArgs e)
        {
           
                this.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update data set ID ='"+textBox1.Text+"'where firstname = '" + textBox2.Text + "'and lastname = '" + textBox3.Text + "'and address = '" + textBox4.Text + "'";
               
                cmd.ExecuteNonQuery();
          
                conn.Close();
                MessageBox.Show("Updated succesfully");
                viewer();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                conn.Close();

            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try {

                textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                
            } 
            catch (Exception ex){
                MessageBox.Show(ex.Message);
            conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                conn.Open();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete * from data where firstname ='" + textBox2.Text + "'";
                cmd.ExecuteNonQuery();

                conn.Close();
                MessageBox.Show("deleted succesfully");
               
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                viewer();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                conn.Close();

            }

        }


        void refresh() {


            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            viewer();
        }
        private void button4_Click(object sender, EventArgs e)
        {

            try
            {
                conn.Open();

                OleDbCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from data where firstname = '"+textBox5.Text+"'or lastname ='"+textBox5.Text+"' ";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                OleDbDataAdapter dp = new OleDbDataAdapter(cmd);
                dp.Fill(dt);
                dataGridView1.DataSource = dt;

                conn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            refresh();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
    }


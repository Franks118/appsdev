﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ddaycare
{
    public partial class createaccount : Form
    {
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\practice.accdb");
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter old = new OleDbDataAdapter();
        public createaccount()
        {
            InitializeComponent();
           
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "" && textBox3.Text == "")
            {

                MessageBox.Show("Fields are empty!!!?1");
            }
            else if (textBox2.Text == textBox3.Text)
            {
                conn.Open();
                string regis = "Insert into login values('" + textBox1.Text + "','" + textBox2.Text + "')";
                cmd = new OleDbCommand(regis,conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("ACCOUNT CREATED SUCCESFULLY");
                Form1 form = new Form1();
                form.Show();
                this.Hide();


            }
            else {

                MessageBox.Show("Password did not match");
                textBox2.Text = "";
                textBox3.Text = "";
                textBox2.Focus();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked) {

                textBox2.PasswordChar = '\0';
                textBox3.PasswordChar = '\0';
            }
            else  {
                textBox2.PasswordChar = '*';
                textBox3.PasswordChar = '*';
            }
        }
    }
}

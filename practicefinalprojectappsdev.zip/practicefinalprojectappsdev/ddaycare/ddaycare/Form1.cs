﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace ddaycare
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
          
        }
       
        OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\practice.accdb");

        OleDbCommand cmd = new OleDbCommand();
        OleDbDataAdapter old = new OleDbDataAdapter();

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            dashboard dashboard = new dashboard();
            string login = "SELECT * FROM login WHERE username ='" + textBox1.Text + "' and password='" + textBox2.Text + "'";
            cmd = new OleDbCommand(login,conn);
            OleDbDataReader reader = cmd.ExecuteReader();
       
            if (reader.Read() == true)
            {

                dashboard.Show();
                this.Hide();
                


            }
            else {
                MessageBox.Show("Wrong information");
                textBox1.Text = "";
                textBox2.Text = "";
                textBox1.Focus();
            }

            conn.Close();


        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
           createaccount create = new createaccount();
            create.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                textBox2.PasswordChar = '\0';
               
            }
            else
            {
                textBox2.PasswordChar = '*';
              
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            termsandagreement terms = new termsandagreement();
            terms.Show();
        }
    }
}

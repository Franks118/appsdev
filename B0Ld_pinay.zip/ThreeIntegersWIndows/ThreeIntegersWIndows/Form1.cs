﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ThreeIntegersWIndows
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Function Button
        private void lblCal_Click(object sender, EventArgs e)
        {
            int num1,num2,num3;
            num1 = Convert.ToInt32(lblnum1.Text);
            num2 = Convert.ToInt32(lblnum2.Text);
            num3 = Convert.ToInt32(lblnum3.Text);

            if (num1 > num2 && num1 > num3) 
                MessageBox.Show("Num1 is the largest.");
            else if (num2 > num3 && num2 > num1) 
                MessageBox.Show("Num2 is the largest.");
            else 
                MessageBox.Show("Num3 is the largest.");

        }
    }
}
